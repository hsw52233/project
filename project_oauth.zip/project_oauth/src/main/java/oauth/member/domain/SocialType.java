package oauth.member.domain;

public enum SocialType {
    KAKAO, NAVER, GOOGLE
}
